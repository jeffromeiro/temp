SELECT 
    r.session_id,
    t.text AS database_being_restored,
    r.command,
    r.status,
    r.percent_complete,
    r.start_time,
    STR(r.estimated_completion_time / 1000.0, 10, 2) AS estimated_completion_seconds,
    STR(r.estimated_completion_time / 1000.0 / 3600.0, 10, 2) AS estimated_completion_hours,
    STR(r.total_elapsed_time / 1000.0, 10, 2) AS total_elapsed_seconds,
    STR(r.total_elapsed_time / 1000.0 / 3600.0, 10, 2) AS total_elapsed_hours,
	    s.login_name,
    s.host_name,
    s.program_name
    FROM 
    sys.dm_exec_requests r
JOIN 
    sys.dm_exec_sessions s ON r.session_id = s.session_id
CROSS APPLY 
    sys.dm_exec_sql_text(r.sql_handle) AS t
WHERE 
    r.command LIKE 'RESTORE%';
