SELECT
		db_name(prc.dbid) as db,
		prc.spid,
		prc.blocked,
		prc.waittime,
		prc.cpu,
		prc.login_time,
		prc.last_batch,
		prc.status,
		prc.cmd,
		PROGRAM_NAME,
		--prc.nt_domain,
		prc.nt_username,
		--prc.loginame,
		--lastwaittype,
		--hostname,
		text
	FROM
		sys.sysprocesses AS prc
		OUTER APPLY sys.dm_exec_sql_text(prc.sql_handle)
	WHERE
		--prc.loginame = 'NT AUTHORITY\NETWORK SERVICE'
		--AND
		prc.spid > 50 
		AND prc.spid <> @@SPID
	--	AND PROGRAM_NAME LIKE '%S.I.C.%'
			AND status not in ('sleeping','background')
			--AND db_name(prc.dbid) IN ('FIPROPAUTCBSS','FICDCCBSS')
	ORDER BY
cpu desc
