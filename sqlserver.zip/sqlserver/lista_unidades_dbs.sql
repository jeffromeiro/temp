WITH DadosAgrupados AS (
    SELECT 
        vs.volume_mount_point AS [Unidade],
        DB_NAME(mf.database_id) AS [Nome_Banco],
        CASE 
            WHEN mf.type_desc = 'ROWS' THEN 'DADOS' 
            ELSE mf.type_desc 
        END AS [Tipo_Arquivo],
        CAST(SUM(mf.size * 8.0) / 1024.0 / 1024.0 AS DECIMAL(10,2)) AS [Espaco_Ocupado_Tipo_GB],
        CAST(MAX(vs.total_bytes) / 1024.0 / 1024.0 / 1024.0 AS DECIMAL(10,2)) AS [Tamanho_Total_Disco_GB],
        CAST(MAX(vs.available_bytes) / 1024.0 / 1024.0 / 1024.0 AS DECIMAL(10,2)) AS [Espaco_Livre_Disco_GB],
        CAST((MAX(vs.available_bytes) * 100.0) / MAX(vs.total_bytes) AS DECIMAL(10,2)) AS [Percentual_Livre_Disco_%]
    FROM sys.master_files AS mf
    CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.file_id) AS vs
    WHERE DB_NAME(mf.database_id) LIKE '%CBSS%'  and DB_NAME(mf.database_id) NOT LIKE 'FITABCORPCBSS_HML'
    GROUP BY 
        vs.volume_mount_point,
        mf.database_id,
        mf.type_desc
),
ResultadoFinal AS (
    -- Retorna os tipos originais (DADOS, LOG, etc.)
    SELECT 
        [Unidade], [Nome_Banco], [Tipo_Arquivo], [Espaco_Ocupado_Tipo_GB], 
        [Tamanho_Total_Disco_GB], [Espaco_Livre_Disco_GB], [Percentual_Livre_Disco_%],
        1 AS [Ordem_Tipo]
    FROM DadosAgrupados

    UNION ALL

    -- Calcula e injeta a linha de TOTAL consolidando e concatenando as unidades
    SELECT 
        'TOTAL: '+STRING_AGG(UnidadesDistintas.[Unidade], ' - ') WITHIN GROUP (ORDER BY UnidadesDistintas.[Unidade]) AS [Unidade],
        TotaisPorBanco.[Nome_Banco], -- Corrigido: Especificado a tabela de origem para evitar a ambiguidade
        'TOTAL' AS [Tipo_Arquivo],
        TotaisPorBanco.[Espaco_Ocupado_Tipo_GB] AS [Espaco_Ocupado_Tipo_GB],
        NULL AS [Tamanho_Total_Disco_GB],
        NULL AS [Espaco_Livre_Disco_GB],
        NULL AS [Percentual_Livre_Disco_%],
        2 AS [Ordem_Tipo]
    FROM (
        SELECT DISTINCT [Unidade], [Nome_Banco] FROM DadosAgrupados
    ) AS UnidadesDistintas
    INNER JOIN (
        SELECT [Nome_Banco], SUM([Espaco_Ocupado_Tipo_GB]) AS [Espaco_Ocupado_Tipo_GB]
        FROM DadosAgrupados
        GROUP BY [Nome_Banco]
    ) AS TotaisPorBanco ON UnidadesDistintas.[Nome_Banco] = TotaisPorBanco.[Nome_Banco]
    GROUP BY TotaisPorBanco.[Nome_Banco], TotaisPorBanco.[Espaco_Ocupado_Tipo_GB]
)
-- Retorno final limpo e ordenado
SELECT 
    [Unidade], 
    [Nome_Banco], 
    [Tipo_Arquivo], 
    [Espaco_Ocupado_Tipo_GB], 
    [Tamanho_Total_Disco_GB], 
    [Espaco_Livre_Disco_GB], 
    [Percentual_Livre_Disco_%]
FROM ResultadoFinal
ORDER BY --[Percentual_Livre_Disco_%],
    [Nome_Banco],   
    [Ordem_Tipo],   
    [Tipo_Arquivo];
