USE tempdb;

SELECT
    [FileSizeMB] = CONVERT(NUMERIC(10,2), ROUND(a.size / 128.0, 2)),
    [UsedSpaceMB] = CONVERT(NUMERIC(10,2), ROUND(FILEPROPERTY(a.name, 'SpaceUsed') / 128.0, 2)),
    [UnusedSpaceMB] = CONVERT(NUMERIC(10,2), ROUND((a.size - FILEPROPERTY(a.name, 'SpaceUsed')) / 128.0, 2)),
    [UsedPercent] = CONVERT(NUMERIC(5,2), 
                    CASE 
                        WHEN a.size > 0 THEN (FILEPROPERTY(a.name, 'SpaceUsed') * 100.0 / a.size)
                        ELSE 0
                    END),
    [DBFileName] = a.name,
    [FileType] = CASE 
                    WHEN a.groupid = 0 THEN 'Log'
                    WHEN a.groupid = 1 THEN 'Data'
                    ELSE 'Unknown'
                 END
FROM
    sysfiles a
ORDER BY
    DBFileName DESC;