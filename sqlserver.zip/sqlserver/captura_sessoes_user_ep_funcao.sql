/*SELECT 
      [collection_time],
      [dd hh:mm:ss.mss],
      [database_name],
      [session_id],
      [blocking_session_id],
      --LEFT(REPLACE(REPLACE(REPLACE(CAST([sql_text] AS NVARCHAR(MAX)), CHAR(13), ''), CHAR(10), ''), CHAR(9), ' '), 200) AS [sql_text],
	  CAST([sql_text] AS NVARCHAR(MAX)) AS SQL_TEXT,
      [login_name],
      [wait_info],
      [status],
      [percent_complete],
      [host_name],
	  CAST([sql_command] AS NVARCHAR(MAX)) AS SQL_COMMAND,
	  --LEFT(REPLACE(REPLACE(REPLACE(CAST([sql_command] AS NVARCHAR(MAX)), CHAR(13), ''), CHAR(10), ''), CHAR(9), ' '), 200) AS [sql_command],
      [CPU],
      [CPU_delta],
      [reads],
      [reads_delta],
      [writes],
      [program_name],
      [open_tran_count]
FROM [monitor].[dbo].[log_whoisactive]
WHERE 
    login_name = 'user_ep_funcao'
    AND UPPER(host_name) LIKE '%IS-TS%%'
    AND PROGRAM_NAME LIKE 'Microsoft SQL Server Management%'
    AND collection_time >= DATEADD(DAY, -90, GETDATE())
--	AND	collection_time BETWEEN '2024-12-03 00:00:00.437' AND '2025-01-31 21:59:01.437'
    AND HOST_NAME like 'IS-TS%' --APP-RTB' 
	--AND HOST_NAME NOT LIKE 'IS-TSAPP-RTB'
ORDER BY collection_time;
*/

select *
FROM [monitor].[dbo].[log_whoisactive]
WHERE 
    login_name = 'user_ep_funcao'
    AND UPPER(host_name) LIKE '%IS-TS%%'
    AND PROGRAM_NAME LIKE 'Microsoft SQL Server Management%'
    --AND collection_time >= DATEADD(DAY, -90, GETDATE())
	AND	collection_time BETWEEN '2024-12-03 00:00:00.437' AND '2025-01-31 21:59:01.437'
    AND HOST_NAME like 'IS-TS%' --APP-RTB' 
ORDER BY collection_time;
