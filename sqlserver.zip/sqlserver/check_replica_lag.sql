SELECT AR.replica_server_name
     , DB_NAME (ARS.database_id) 'database_name'
     , AR.availability_mode_desc
     , ARS.synchronization_health_desc
     , ARS.last_hardened_lsn
     , ARS.last_redone_lsn
     , ARS.secondary_lag_seconds
FROM sys.dm_hadr_database_replica_states ARS
INNER JOIN sys.availability_replicas AR ON ARS.replica_id = AR.replica_id
--where availability_mode_desc='ASYNCHRONOUS_COMMIT'
where  DB_NAME (ARS.database_id)  = 'FIMONITORCBSS'
ORDER BY DB_NAME (ARS.database_id), AR.replica_server_name, synchronization_health_desc desc;
