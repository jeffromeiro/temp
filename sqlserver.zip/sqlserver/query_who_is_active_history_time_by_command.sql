use monitor

DECLARE @login_name VARCHAR(20) = null;
DECLARE @session_id NUMERIC(20) = 178;
DECLARE @horas NUMERIC(20) = 18;

SELECT * /* min(collection_time) inicio, max(collection_time) fim, 
datediff(minute, min(collection_time) ,max(collection_time)) as minutes, 
       cast(sql_text as nvarchar(max)) as comando,*/
  FROM monitor.[dbo].[log_whoisactive]
where --collection_time > DATEADD(HOUR, -@horas, GETDATE())
--and 
collection_time between '2026-08-31 06:00:00.437' and '2026-08-31 06:10:01.437'
and 
login_name = IIF(@login_name IS NULL, login_name, @login_name)
--and session_id= @session_id
--and 
-- session_id =  IIF(@session_id IS NULL, session_id, @session_id)
--GROUP BY cast(sql_text as nvarchar(max))
order by 1;


DECLARE @login_name VARCHAR(20) = null;
DECLARE @session_id NUMERIC(20) = null;
DECLARE @horas NUMERIC(20) = 9;

SELECT min(collection_time) inicio, max(collection_time) fim, 
datediff(minute, min(collection_time) ,max(collection_time)) as minutes, database_name,SESSION_ID,
       cast(sql_command as nvarchar(max)) as comando,
	   cast(sql_text as nvarchar(max)) as texto,
	    max(reads) reads, program_name, wait_info
  FROM monitor.[dbo].[log_whoisactive]
--where collection_time > DATEADD(HOUR, -@horas, GETDATE())
--and collection_time between '2024-10-03 19:00:00.437' and '2024-10-03 23:46:01.437'
where collection_time between '2026-08-28 01:00:00.437' and '2026-09-15 23:59:00.437'
and login_name = IIF(@login_name IS NULL, login_name, @login_name)
--and session_id= @session_id
and session_id =  IIF(@session_id IS NULL, session_id, @session_id)
--and cast(sql_text as nvarchar(max)) like '%BACKUP DATABASE%'
and database_name='FICDCCBSS'
and program_name='Consulta de Cobran�a Web - BANCO DIGIO S.A.'
GROUP BY session_id,cast(sql_text as nvarchar(max)),cast(sql_command as nvarchar(max)),program_name,wait_info,database_name
order by 4,1;

	select collection_time, database_name,program_name, 
	count(*) as qtd_sessoes
	  FROM monitor.[dbo].[log_whoisactive]
	where collection_time 
	between '2026-09-09 09:00:00.437' and '2026-09-20 23:59:00.437'
	and program_name in ('Acionador de Plugin - FI.SrvINSSExe')
	--and database_name in ('FICDCCBSS')
	group by collection_time, database_name, program_name
	ORDER BY collection_time;


	select *
	  FROM monitor.[dbo].[log_whoisactive]
	where collection_time 
	between '2026-09-09 09:00:00.437' and '2026-09-20 23:59:00.437'
	and program_name in ('Acionador de Plugin - FI.SrvINSSExe')
	ORDER BY collection_time;

	select collection_time, database_name, session_id, login_name, host_name, program_name
	  FROM monitor.[dbo].[log_whoisactive]
	where collection_time 
	between '2026-06-01 00:00:00.437' and '2026-08-24 23:59:00.437'
		ORDER BY collection_time;




select  collection_time, database_name,  sql_command , reads 
from monitor.[dbo].[log_whoisactive]
WHERE program_name in ('Consulta de Cobran�a Web - BANCO DIGIO S.A.')
AND collection_time between '2026-01-10 19:00:00.437' and '2026-09-15 23:59:00.437'
AND UPPER(cast(sql_command as nvarchar(max))) like '%FICDCCBSS.dbo.FI_SP_CDC_SelFluxoPrestacoesV38;1%'
ORDER BY collection_time



select  *
from monitor.[dbo].[log_whoisactive]
WHERE program_name in ('Consulta de Cobran�a Web - BANCO DIGIO S.A.')
AND collection_time between '2026-01-10 19:00:00.437' and '2026-09-15 23:59:00.437'
AND UPPER(cast(sql_command as nvarchar(max))) like '%FICDCCBSS.dbo.FI_SP_CDC_SelFluxoPrestacoesV38;1%'
ORDER BY collection_time


SELECT 
    DATEADD(HOUR, DATEDIFF(HOUR, 0, collection_time), 0) AS collection_time_hour,
    database_name, 
    CAST(sql_command AS NVARCHAR(MAX)) AS sql_command,
    sum(TRY_CAST(REPLACE(REPLACE(reads, ',', ''), '.', '') AS BIGINT)) AS total_reads,
	    avg(TRY_CAST(REPLACE(REPLACE(reads, ',', ''), '.', '') AS BIGINT)) AS avg_reads
		FROM monitor.[dbo].[log_whoisactive] 
WHERE program_name IN ('Consulta de Cobran�a Web - BANCO DIGIO S.A.') 
  AND collection_time BETWEEN '2026-01-10 19:00:00.437' AND '2026-09-15 23:59:00.437' 
  AND UPPER(CAST(sql_command AS NVARCHAR(MAX))) LIKE '%FICDCCBSS.DBO.FI_SP_CDC_SELFLUXOPRESTACOESV38;1%'
GROUP BY 
    DATEADD(HOUR, DATEDIFF(HOUR, 0, collection_time), 0),
    database_name,
    CAST(sql_command AS NVARCHAR(MAX))
ORDER BY 
    collection_time_hour;

 
select top 10 * from monitor.[dbo].[log_whoisactive]
SELECT collection_time, database_name, program_name, sql_text, host_name, query_plan, wait_info FROM monitor.[dbo].[log_whoisactive] 
where collection_time between '2026-04-15 21:32:02.820' and '2026-04-15 23:52:02.820'
--and database_name='FIACESSOEP'
and program_name in ('Parcelas','Dados Financeiros Opera��es')
--and session_id=2009
order by collection_time, database_name, program_name


--1894 - Web Api: Consulta e Altera��o de Clientes CP
--1628 - Dados Financeiros Opera��es
--1816 - FIACESSOEP.dbo.FI_SP_ExcUsuarioEx;1


SELECT min(collection_time) inicio, max(collection_time) fim, 
datediff(minute, min(collection_time) ,max(collection_time)) as minutes, 
       cast(sql_command as nvarchar(max)) as comando,
	    session_id
  FROM [dbo].[log_whoisactive]
where collection_time between '2026-04-15 21:00:00.437' and '2026-04-15 23:59:00.437'
--and program_name='Autorizador Web .NET'
--and cast(sql_command as nvarchar(max)) like '%UPDATE%'
AND SESSION_ID=134
GROUP BY session_id,cast(sql_command as nvarchar(max))
order by 1;



select *--  collection_time, database_name, cast(sql_command as nvarchar(max)), count(*) as sessoes_ativas
  FROM [monitor].[dbo].[log_whoisactive] WITH (NOLOCK)
where login_name='temp_sustentacao'
order by collection_time


select *-- min(collection_time) as primeira_utilizacao,
-- max(collection_time) as ultima_utilizacao--  collection_time, database_name, cast(sql_command as nvarchar(max)), count(*) as sessoes_ativas
  FROM [dbo].[log_whoisactive]
 where collection_time > DATEADD(DAY, -20, GETDATE())
--collection_time between  '2025-10-21 09:00:00.437' and '2025-10-21 10:00:01.437'
and 
login_name='temp_sustentacao'
order by collection_time desc



--and session_id=282
--and cast(sql_command as nvarchar(max)) like '%FIPROPAUTCBSS.dbo.FI_SP_AUT_ValNaoMePerturbePorTelefone_168_V3;1%'
--and cast(sql_text as nvarchar(max)) like '%TOP 1%'
--group by  collection_time, database_name, cast(sql_command as nvarchar(max))
order by collection_time
----
select collection_time, database_name, session_id, blocking_session_id, sql_text, login_name, wait_info, host_name, program_name--collection_time, host_name 
  FROM monitor.[dbo].[log_whoisactive]
where collection_time --> DATEADD(HOUR, -1, GETDATE())-- 
--='2026-02-10 16:10:02.793'
--='2026-02-10 16:30:09.320'
between '2026-02-10 15:50:00.437' and '2026-02-10 17:40:01.437'
and session_id=646
ORDER BY collection_time
--646





select *
--count(*)--collection_time, host_name 
  FROM [dbo].[log_whoisactive]
--where collection_time --> DATEADD(HOUR, -1, GETDATE())-- 
--between  '2025-02-21 00:00:00.437' and '2025-02-21 05:59:01.437'
where collection_time --= '2026-02-21 02:22:03.243'
between  '2026-02-21 00:00:00.437' and '2026-02-21 13:00:01.437'
--and database_name='FICDCCBSS'
and session_id=843
--and program_name in ('Web Api: Consultar os dados de uma opera��o.','Acionador de Plugin - FI.SrvINSSExe')
--group by collection_time, database_name, program_name, cast(sql_command as nvarchar(max))
ORDER BY collection_time


exec sp_helptext FI_SP_RLCDC_MTRCPCNT_V32_BASE

	select *--collection_time, host_name 
	  FROM monitor.[dbo].[log_whoisactive]
	where collection_time --> DATEADD(HOUR, -1, GETDATE())-- 
	between '2025-08-26 11:00:00.437' and '2025-09-26 17:00:01.437'
	and upper(login_name) like '%SvcprdfuncaoPWC%'
	--and database_name='FIPROPAUTCBSS'



select *--collection_time, host_name 
  FROM [dbo].[log_whoisactive]
where collection_time --> DATEADD(HOUR, -1, GETDATE())-- 
between '2024-12-03 00:00:00.000' and '2024-12-03 23:59:59.437'
--and login_name='user_ep_funcao'
and host_name in ('PRD-FCON-SVC01','PRD-FCON-SVC02')
order by login_name, session_id, collection_time
 


--and database_name='FIPROPAUTCBSS'
and session_id=282


select *
  FROM [dbo].[log_whoisactive]
where collection_time --> DATEADD(HOUR, -1, GETDATE())-- 
between '2024-12-03 18:10:00.437' and '2024-12-03 19:50:01.437'
and program_name like 'Microsoft SQL Server Management Studio%'
order by collection_time


SELECT UserID, UserName, EncryptedPassword
FROM dbo.Users

USE master;
GO
SELECT name, pvt_key_encryption_type_desc FROM sys.certificates;
GO

--and 
--and host_name in ('EC2AMAZ-4247530','EC2AMAZ-6R8P6KO')
--and login_name='master'
and session_id IN (735)
--AND database_name='FIPROPAUTCBSS'
--and cast(sql_command as nvarchar(max)) like '%UPDATE%'
--AND login_name <> 'USER_OPENFINANCE_CDC'
order by collection_time



select host_name, count(*)--collection_time, host_name 
  FROM [dbo].[log_whoisactive]
where --collection_time --> DATEADD(HOUR, -1, GETDATE())-- 
--between '2024-12-03 10:00:00.437' and '2024-12-03 21:59:01.437'
--and
login_name='user_ep_funcao'
and upper(host_name) like '%IS-TS%%'
group by host_name
order by 2 desc

use monitor
go
select collection_time, session_id, database_name, sql_text,sql_command,login_name, status, host_name,program_name,query_plan,reads_delta
  FROM [dbo].[log_whoisactive] 
where collection_time > DATEADD(DAY, -3, GETDATE())-- 
--between '2024-12-03 10:00:00.437' and '2024-12-03 21:59:01.437'
and
login_name='user_app_funcao'
--and upper(host_name) like '%IS-TS%%'
--and PROGRAM_NAME like 'Microsoft SQL Server%'
--and collection_time between '2024-12-03 00:00:00.437' and '2025-01-31 21:59:01.437'
--and collection_time between '2025-06-05 00:00:00.437' and '2025-06-21 21:59:01.437'
-- and 
 --UPPER(cast(sql_command as nvarchar(max))) like '%BACEN%'
and UPPER(cast(sql_command as nvarchar(max))) like '%DROP TABLE%'
-- and HOST_NAME='IS-TSAPP-RTB'
-- group by host_name
order by collection_time



--and 
--and host_name in ('EC2AMAZ-4247530','EC2AMAZ-6R8P6KO')
--and login_name='master'
--AND database_name='FIPROPAUTCBSS'
--and cast(sql_command as nvarchar(max)) like '%UPDATE%'
--AND login_name <> 'USER_OPENFINANCE_CDC'
order by collection_time

----------------

select * /*TOP 10 session_id, cast(sql_text as nvarchar(max)) as sql_text,
cast(sql_command as nvarchar(max)) as comando, login_name,  host_name,  program_name, 
max(replace(CPU,',','')) as CPU */
  FROM [dbo].[log_whoisactive]
where --collection_time > DATEADD(HOUR, -12, GETDATE())
--and session_id=374
--and 
--login_name='user_ep_funcao' and
--and cast(sql_text as nvarchar(max))
--collection_time between '2024-10-08 07:45:00.437' and '2024-10-08 07:49:01.437'
collection_time between '2024-07-18 10:00:00.000' and '2024-11-19 22:48:00.000'
and CPU_delta is not null
and replace(CPU,',','') > 1000000	
and database_name='FIPOSITIVOCBSS'
and cast(sql_text as nvarchar(max)) like '%SELECT CLCGC, (CASE CLTPFJ  WHEN%'
--GROUP BY session_id,cast(sql_text as nvarchar(max)), cast(sql_command as nvarchar(max)), login_name,  host_name,  program_name--
ORDER BY 1 DESC


DECLARE @login_name VARCHAR(20) = null;
DECLARE @session_id NUMERIC(20) = null;
--DECLARE @horas NUMERIC(20) = 3;

SELECT [dd hh:mm:ss.mss],session_id,(collection_time) , 
       cast(sql_command as nvarchar(max)) as comando,
	    reads, CPU
  FROM [dbo].[log_whoisactive]
where --collection_time > DATEADD(HOUR, -@horas, GETDATE())
--and 
collection_time between '2024-10-23 10:00:00.437' and '2024-10-25 23:46:01.437'
and login_name = IIF(@login_name IS NULL, login_name, @login_name)
--and session_id= @session_id
and session_id =  IIF(@session_id IS NULL, session_id, @session_id)
and program_name='Autorizador Web .NET'
order by 1 desc;


select *
  FROM [dbo].[log_whoisactive]
where collection_time --> DATEADD(HOUR, -1, GETDATE())-- 
between '2024-12-03 18:10:00.437' and '2024-12-03 19:50:01.437'
--and login_name='user_ep_funcao'
and program_name like 'Microsoft SQL Server Management Studio%'
and UPPER(cast(sql_text as nvarchar(max))) like '%UPDATE%COPER%900000820758304%'
--and database_name='FIPROPAUTCBSS'
--and session_id <> 282


select distinct host_name
  FROM [dbo].[log_whoisactive]
  where collection_time --> DATEADD(HOUR, -1, GETDATE())-- 
> '2023-12-03 18:10:00.437'
  and host_name <> ''
   and login_name='user_ep_funcao'
  order by 1 desc




  use FIACESSOCBSS

  SELECT * FROM TAUDITC WITH (NOLOCK), TAUDITD WITH (NOLOCK), TUSU WITH (NOLOCK)
WHERE --ACURLPAGE LIKE '%FiApiAcessoUsuario%Usuario%SituacaoUsuario%'
--AND 
ACDTSIS between '2024-12-03 18:10:00.437' and '2024-12-03 19:50:01.437'
AND USNOMEUSU = ACNOMEUSU
AND ACID = ADID
and aclogin='USER_EP_FUNCAO'



select * FROM CPARC WITH(NOLOCK) WHERE PANROPER = '900000820758304'

SELECT PRO.loginame AS LoginName, DB.name AS DatabaseName, CONVERT(varchar(max),PRO.sql_handle,1) AS sql_handle, PRO.[status] as ProcessStatus, 
PRO.cmd AS Command, PRO.last_batch AS LastBatch, PRO.cpu AS Cpu, PRO.physical_io AS PhysicalIo, STM.[text] AS SQLStatement, CONVERT(varchar(128),
SERVERPROPERTY('ServerName')) AS ServerName, CONVERT(varchar(128),CONNECTIONPROPERTY('local_tcp_port')) AS port 
FROM sys.sysprocesses AS PRO INNER JOIN sys.databases AS DB ON PRO.dbid = DB.database_id CROSS APPLY
sys.dm_exec_sql_text(PRO.sql_handle) AS STM WHERE PRO.spid >= 50
 