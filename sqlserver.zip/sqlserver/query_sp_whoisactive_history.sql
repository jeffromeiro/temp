use monitor

DECLARE @login_name VARCHAR(20) = null;
DECLARE @session_id NUMERIC(20) = null;
DECLARE @horas NUMERIC(20) = 6;

SELECT [collection_time]
,[host_name]
      ,[dd hh:mm:ss.mss]
     ,[login_name]
	 ,[database_name]
      ,[session_id]
      ,[status]
	,[sql_text]
      ,[wait_info]
      ,[blocking_session_id]
    	,[percent_complete]
            ,[sql_command]
      ,[CPU]
      ,[CPU_delta]
      ,[reads]
      ,[reads_delta]
      ,[writes]
      ,[program_name]
      ,[open_tran_count]
      ,[query_plan]
  FROM [dbo].[log_whoisactive]
where collection_time > DATEADD(HOUR, -@horas, GETDATE())
and login_name = IIF(@login_name IS NULL, login_name, @login_name)
--and host_name in ('EC2AMAZ-6R8P6KO','EC2AMAZ-4247530')
--and program_name='Microsoft� Windows� Operating System'
--and session_id= @session_id
--and database_name='FIPOSITIVOCBSS'
and session_id =  IIF(@session_id IS NULL, session_id, @session_id)
order by 1 desc;
