SELECT
	DB_NAME() AS DBName,
	c.name AS TableName,
	c.type_desc,
	b.name AS IndexName,
	a.index_type_desc,
	cast(a.avg_fragmentation_in_percent AS int) AS avg_fragmentation_in_percent,
	a.fragment_count, cast(a.avg_fragment_size_in_pages AS int) AS avg_fragment_size_in_pages,
		CASE	
			WHEN a.avg_fragmentation_in_percent between 5 and 30 THEN 'Reorganize'
			WHEN a.avg_fragmentation_in_percent > 30 THEN 'Rebuild'
			ELSE 'OK'
		END AS [Action]
FROM 
		sys.dm_db_index_physical_stats(DB_ID(),null,null,null,null) AS a
		INNER JOIN sys.indexes b ON (a.object_id = b.object_id AND  a.index_id = b.index_id)
		INNER JOIN sys.tables c ON a.object_id = c.object_id
WHERE 
		a.avg_fragmentation_in_percent > 30
		AND  a.fragment_count >= 1000
  --  AND
	--c.name = 'CPARC'
		--AND index_type_desc <> 'HEAP'
ORDER BY 6 DESC, 7 DESC;