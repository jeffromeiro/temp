WITH BlockingInfo AS (
    SELECT
        r.blocking_session_id AS BlockingSession,
        r.session_id AS BlockedSession,
        r.wait_time / 1000.0 AS WaitTimeInSeconds,
        r.wait_type AS WaitType,
        r.start_time AS BlockingStartTime,
        DATEDIFF(SECOND, r.start_time, GETDATE()) AS BlockingTotalExecutionTimeSeconds,
        s.login_name AS LoginName,
        s.program_name AS ProgramName,
        c.client_net_address AS Hostname,
        db_name(r.database_id) AS DatabaseName
    FROM sys.dm_exec_requests r
    JOIN sys.dm_exec_sessions s ON r.session_id = s.session_id
    LEFT JOIN sys.dm_exec_connections c ON r.session_id = c.session_id
    WHERE r.blocking_session_id <> 0
)
SELECT
    bi.BlockingSession AS Sessao_Bloqueadora,
    bi.BlockedSession AS Sessao_Bloqueada,
    bs.login_name AS Login_Sessao_Bloqueadora,
    bs.program_name AS Program_Sessao_Bloqueadora,
    bc.client_net_address AS Hostname_Sessao_Bloqueadora,
    bi.LoginName AS Login_Sessao_Bloqueada,
    bi.ProgramName AS Program_Sessao_Bloqueada,
    bi.DatabaseName,
    CONVERT(VARCHAR(12), DATEADD(SECOND, bi.BlockingTotalExecutionTimeSeconds, 0), 108) AS Tempo_Total_Bloqueio,
    CONVERT(VARCHAR(12), DATEADD(SECOND, bi.WaitTimeInSeconds, 0), 108) AS Tempo_Total_Sessao_Bloqueada,
    bi.WaitType AS Tipo_Espera
FROM BlockingInfo bi
LEFT JOIN sys.dm_exec_sessions bs ON bi.BlockingSession = bs.session_id
LEFT JOIN sys.dm_exec_connections bc ON bi.BlockingSession = bc.session_id
