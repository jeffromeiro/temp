-- Habilitar a execu��o de comandos din�micos
SET NOCOUNT ON;

-- Vari�vel para armazenar o comando din�mico
DECLARE @sql NVARCHAR(MAX);

-- Inicializar a vari�vel
SET @sql = '';

-- Criar tabela tempor�ria para armazenar os resultados
IF OBJECT_ID('tempdb..#ShrinkSpace') IS NOT NULL
    DROP TABLE #ShrinkSpace;

CREATE TABLE #ShrinkSpace (
    DatabaseName NVARCHAR(128),
    FileName NVARCHAR(128),
    FileType NVARCHAR(128),
    CurrentSizeMB DECIMAL(18,2),
    SpaceUsedMB DECIMAL(18,2),
    SpaceToFreeMB DECIMAL(18,2)
);

-- Loop atrav�s de todos os bancos de dados
SELECT @sql = @sql + '
USE [' + name + '];

-- Estimar espa�o a ser liberado
INSERT INTO #ShrinkSpace (DatabaseName, FileName, FileType, CurrentSizeMB, SpaceUsedMB, SpaceToFreeMB)
SELECT 
    DB_NAME() AS DatabaseName,
    f.name AS FileName,
    f.type_desc AS FileType,
    f.size / 128.0 AS CurrentSizeMB,
    FILEPROPERTY(f.name, ''SpaceUsed'') / 128.0 AS SpaceUsedMB,
    (f.size - FILEPROPERTY(f.name, ''SpaceUsed'')) / 128.0 AS SpaceToFreeMB
FROM 
    sys.database_files AS f
WHERE 
    f.type IN (0, 1); -- Incluir apenas arquivos de dados e log
' 
FROM sys.databases
WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb'); -- Excluir bancos de dados do sistema

-- Executar o comando din�mico
EXEC sp_executesql @sql;

-- Selecionar os resultados da tabela tempor�ria
SELECT * FROM #ShrinkSpace order by SpaceToFreeMB desc;

-- Limpar a tabela tempor�ria
DROP TABLE #ShrinkSpace;