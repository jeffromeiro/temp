use monitor
EXEC monitor.dbo.sp_WhoIsActive @get_outer_command=1, @get_plans=1, @get_transaction_info= 1   ,@filter_type='session', @filter='831',@output_column_list= '[per%][dd%][tran_start%][database%][sql_%][locks][%]'

EXEC monitor.dbo.sp_WhoIsActive @get_outer_command=1, @get_plans=1, @get_task_info=2, @get_transaction_info= 1, @output_column_list= '[dd%][tasks][CPU][tran_start%][database%][sql_%][locks][%]',@filter_type='login', @filter='user_app_funcao'
--@output_column_list VARCHAR(8000) = '[dd%][tran_log%][session_id][sql_text][sql_command][login_name][wait_info][tasks][cpu%][temp%][block%][reads%][writes%][context%][physical%][query_plan][locks][%]'
-- exec sp_who2

/*EXEC monitor.dbo.sp_WhoIsActive 
    @get_outer_command = 1, 
    @get_plans = 1, 
    @get_transaction_info = 1,
    @filter_type = 'session', 
    @filter = '1629',
    @show_sleeping_spids = 2, -- <--- FOR�A MOSTRAR SE ESTIVER DORMINDO
    @show_own_spid = 1,       -- <--- FOR�A MOSTRAR SE FOR SUA PR�PRIA SESS�O
    @output_column_list = '[per%][dd%][tran_start%][database%][sql_%][locks][%]'
*/

--select * from sys.sysprocesses where loginame <> 'sa'
