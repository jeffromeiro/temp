--EXEC sp_WhoIsActive @get_outer_command=1, @get_plans=1, @get_transaction_info= 1   ,@filter_type='session', @filter='843',@output_column_list= '[per%][dd%][tran_start%][database%][sql_%][locks][%]'


USE MASTER 
SELECT
    SPID                = er.session_id
    ,dop = er.dop   
    ,BlkBy              = er.blocking_session_id      
    ,ElapsedMS          = er.total_elapsed_time
	,ElapsedSeconds����� = CAST(er.total_elapsed_time / 1000 AS INT)
    ,CPU                = er.cpu_time
    ,IOReads            = er.logical_reads + er.reads
    ,IOWrites           = er.writes         
    ,CommandType        = er.command         
	    ,[Login]            = ses.login_name
		    ,ObjectName         = OBJECT_SCHEMA_NAME(qt.objectid,dbid) + '.' + OBJECT_NAME(qt.objectid, qt.dbid)    
					    ,ProgramName        = ses.program_name 
			    ,Host               = ses.host_name        
    ,WaitType           = er.wait_type
    ,WaitResource       = er.wait_resource
    ,WaitTime           = er.wait_time
	,DBName             = DB_Name(er.database_id)  
    ,LastWaitType       = er.last_wait_type 
    ,Executions         = ec.execution_count 
    ,SQLStatement       =
        SUBSTRING(
        REPLACE(REPLACE(
        SUBSTRING
        (
            qt.text,
            er.statement_start_offset/2,
            (CASE WHEN er.statement_end_offset = -1
                THEN LEN(CONVERT(nvarchar(MAX), qt.text)) * 2
                ELSE er.statement_end_offset
                END - er.statement_start_offset)/2
        ), CHAR(13), '|'), CHAR(10), '|'), 0 , 300) + '...' 
    ,STATUS             = ses.STATUS
    ,parallel_worker_count = parallel_worker_count
	    ,Grupo_max_dop = B.max_dop
    ,granted_memory_kb = dmm.granted_memory_kb
    ,requested_memory_kb = dmm.requested_memory_kb
    ,used_memory_kb = dmm.used_memory_kb
    ,resource_semaphore_id = dmm.resource_semaphore_id
    ,Client_interface   = ses.client_interface_name
    ,StartTime          = er.start_time
    ,Protocol           = con.net_transport
    ,transaction_isolation =
        CASE ses.transaction_isolation_level
            WHEN 0 THEN 'Unspecified'
            WHEN 1 THEN 'Read Uncommitted'
            WHEN 2 THEN 'Read Committed'
            WHEN 3 THEN 'Repeatable'
            WHEN 4 THEN 'Serializable'
            WHEN 5 THEN 'Snapshot'
        END
    ,ConnectionWrites   = con.num_writes
    ,ConnectionReads    = con.num_reads
    ,ClientAddress      = con.client_net_address
    ,Authentication     = con.auth_scheme   
    ,Grupo =  B.name
    ,Grupo_effective_max_dop = B.effective_max_dop
    ,Grupo_max_request_grant_memory_kb = B.max_request_grant_memory_kb 
    ,Grupo_request_max_memory_grant_percent =  B.request_max_memory_grant_percent
    ,Grupo_pool_id =  B.pool_id
    ,Grupo_statistics_start_time =  B.statistics_start_time
FROM sys.dm_exec_requests er WITH(NOLOCK)
LEFT JOIN sys.dm_exec_sessions ses WITH(NOLOCK)
ON ses.session_id = er.session_id 
LEFT JOIN sys.dm_exec_connections con WITH(NOLOCK)
ON con.session_id = ses.session_id
CROSS APPLY sys.dm_exec_sql_text(er.sql_handle) AS qt OUTER APPLY (
    SELECT execution_count = MAX(cp.usecounts)
    FROM sys.dm_exec_cached_plans cp WITH(NOLOCK)
    WHERE cp.plan_handle = er.plan_handle
) ec
LEFT JOIN sys.dm_resource_governor_workload_groups B WITH(NOLOCK) ON ses.group_id = B.group_id
LEFT JOIN sys.dm_exec_query_memory_grants dmm WITH(NOLOCK) on dmm.session_id = er.session_id
--WHERE DB_Name(er.database_id) ='FICDCEP'--last_wait_type <> 'WAITFOR' 
--where er.session_id=1553
--where DB_Name(er.database_id) ='FIMONITORCBSS' and er.command='KILLED/ROLLBACK'
--where DB_Name(er.database_id) ='FIMONITORCBSS' and er.command='INSERT'
--and OBJECT_SCHEMA_NAME(qt.objectid,dbid) + '.' + OBJECT_NAME(qt.objectid, qt.dbid)='dbo.FI_SP_AUT_ValNaoMePerturbePorTelefone_168_V3'
ORDER BY --er.session_id,--DOP DESC,
	--DB_Name(er.database_id)  ,
	--er.blocking_session_id desc,
--OBJECT_SCHEMA_NAME(qt.objectid,dbid) + '.' + OBJECT_NAME(qt.objectid, qt.dbid) ,
    er.cpu_time DESC,
    er.logical_reads + er.reads DESC
	--,    er.session_id

	
