SELECT * FROM monitor..vw_gera_bloqueios WHERE Tempo_Total_Bloqueio >= '00:01:00'
