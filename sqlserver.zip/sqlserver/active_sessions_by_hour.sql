-- Janela de an�lise (ajuste conforme necess�rio)
DECLARE @dt_inicial DATETIME = DATEADD(DAY, -1, SYSDATETIME());  -- �ltimos 7 dias (exemplo)
DECLARE @dt_final   DATETIME = SYSDATETIME();

;WITH base AS
(
    SELECT
        -- Bucket de hora (arredonda para o in�cio da hora)
        DATEADD(HOUR, DATEDIFF(HOUR, 0, collection_time), 0) AS hora,
        login_name,
        database_name,
        program_name,
        session_id,
        status,

        -- Converte o XML para texto. Mantemos duas representa��es:
        -- 1) texto truncado (NVARCHAR(4000)) para agrupar/mostrar
        -- 2) hash SHA2_256 do texto completo para diferenciar comandos iguais sem depender do truncamento
        CAST(TRY_CONVERT(NVARCHAR(MAX), sql_command) AS NVARCHAR(4000)) AS sql_command_text_4000,
        CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', TRY_CONVERT(NVARCHAR(MAX), sql_command)), 2) AS sql_command_hash
    FROM dbo.log_whoisactive WITH (NOLOCK)
    WHERE
        collection_time >= @dt_inicial
        AND collection_time <  @dt_final

        -- "Ativas": exclui sleeping (ajuste para = 'running' se quiser s� consumo de CPU)
        AND status <> 'sleeping'

        -- Sess�es de usu�rio (evita tasks de sistema)
        AND session_id >= 50

        -- Filtro solicitado
        AND program_name = N'Acionador de Plugin - FI.SrvINSSExe'
		
)
, amostras_por_hora AS
(
    -- Conta quantas coletas foram feitas em cada hora (�til para normalizar)
    SELECT
        hora,
        COUNT(DISTINCT collection_time_bucket) AS amostras_na_hora
    FROM
    (
        SELECT
            DATEADD(MINUTE, DATEDIFF(MINUTE, 0, collection_time), 0) AS collection_time_bucket, -- normaliza minuto
            DATEADD(HOUR,   DATEDIFF(HOUR,   0, collection_time), 0) AS hora
        FROM dbo.log_whoisactive WITH (NOLOCK)
        WHERE
            collection_time >= @dt_inicial
            AND collection_time <  @dt_final
    ) s
    GROUP BY hora
)
SELECT
    b.hora                                  AS hora_inicio,
    b.login_name,
    b.database_name,
    b.program_name,

    -- Representa��o do comando
    COALESCE(b.sql_command_text_4000, N'(NULL)') AS sql_command_text_4000,
    COALESCE(b.sql_command_hash, '(NULL)')       AS sql_command_hash,

    COUNT(DISTINCT b.session_id)            AS sessoes_ativas,          -- distintas na hora
    a.amostras_na_hora,
    CAST(1.0 * COUNT(DISTINCT b.session_id) / NULLIF(a.amostras_na_hora, 0) AS DECIMAL(10,2))
                                            AS media_ativas_por_amostra
FROM base b
JOIN amostras_por_hora a
  ON a.hora = b.hora
  --and b.sql_command_text_4000 like '%FIPROPAUTCBSS.dbo.FI_SP_AVBPROP_SelFechamentoVariavel_V5%'
GROUP BY
    b.hora,
    b.login_name,
    b.database_name,
    b.program_name,
    b.sql_command_text_4000,
    b.sql_command_hash,
    a.amostras_na_hora
ORDER BY
    b.hora,
    b.login_name,
    b.database_name,
    b.program_name,
    b.sql_command_hash;   -- hash garante ordena��o consistente mesmo se o texto truncar