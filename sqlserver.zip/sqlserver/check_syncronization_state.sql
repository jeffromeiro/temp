SELECT
    ag.name                                 AS ag_name,
    ar.replica_server_name                  AS replica_name,
    db.name                                 AS database_name,
    ars.role_desc,
    drs.synchronization_state_desc,
    drs.synchronization_health_desc,
    -- Tamanho das filas (KB). Se crescer, h� atraso de envio/aplica��o.
    drs.log_send_queue_size                 AS log_send_queue_kb,
    drs.redo_queue_size                     AS redo_queue_kb,
    -- M�tricas de commit
    drs.last_commit_time,
    drs.last_redone_time,
    -- Lag aproximado entre �ltimo commit no prim�rio e redone no secund�rio (segundos)
    DATEDIFF(SECOND, drs.last_redone_time, drs.last_commit_time) AS approx_commit_lag_sec
FROM sys.availability_groups AS ag
JOIN sys.availability_replicas AS ar
    ON ag.group_id = ar.group_id
JOIN sys.dm_hadr_availability_replica_states AS ars
    ON ar.replica_id = ars.replica_id
JOIN sys.dm_hadr_database_replica_states AS drs
    ON ar.replica_id = drs.replica_id
JOIN sys.databases AS db
    ON drs.database_id = db.database_id
--ORDER BY ag.name, db.name, ars.role_desc, ar.replica_server_name;
--where db.name='FIMONITORCBSS'
ORDER BY 8 desc;
