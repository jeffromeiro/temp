USE FICDCCBSS;
GO

SELECT
    OBJECT_SCHEMA_NAME(s.object_id) AS SchemaName,
    OBJECT_NAME(s.object_id) AS Tabela,
    s.name AS Estatistica,
    sp.last_updated AS UltimaAtualizacao,
    sp.rows AS QtdeLinhas,
    sp.modification_counter AS ModificacoesDesdeUltimoUpdate,
    CAST(
        (sp.modification_counter * 100.0) /
        NULLIF(sp.rows,0)
        AS DECIMAL(10,2)
    ) AS PercAlterado
FROM sys.stats s
CROSS APPLY sys.dm_db_stats_properties(s.object_id, s.stats_id) sp
WHERE OBJECTPROPERTY(s.object_id, 'IsUserTable') = 1
    AND s.name NOT LIKE '_WA_Sys%'
    AND sp.last_updated <= DATEADD(DAY, -2, GETDATE())
    AND sp.modification_counter > 0
ORDER BY sp.modification_counter DESC;