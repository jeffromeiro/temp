cdc_help

SELECT * FROM sys.dm_cdc_log_scan_sessions -- where empty_scan_count <> 0;
order by latency desc

-- FICDCEP - OK
-- FIPROPAUTEP - OK
-- FITABCORPCBSS - OK
--FIPROPAUTCBSS
--FICDCCBSS

exec rdsadmin.dbo.rds_show_configuration 'cdc_capture_maxtrans';
exec rdsadmin.dbo.rds_show_configuration 'cdc_capture_maxscans';
exec rdsadmin.dbo.rds_show_configuration 'cdc_capture_pollinginterval';

exec sys.sp_cdc_help_jobs

exec rdsadmin.dbo.rds_set_configuration 'cdc_capture_maxscans', 100;
exec rdsadmin.dbo.rds_set_configuration 'cdc_capture_maxtrans', 1000;
exec rdsadmin.dbo.rds_set_configuration 'cdc_capture_pollinginterval', 1800;
 

select count(*) from efina
 
 select * from sys.dm_cdc_errors;
 
 select * from sys.databases where is_cdc_enabled = 1



 exec sys.sp_cdc_help_change_data_capture 

 SELECT  sc.name AS [Schema], t.name AS [NomeTabela], t.is_tracked_by_cdc AS [Traked By CDC]
 FROM sys.tables AS t
INNER JOIN sys.schemas AS sc ON t.schema_id = sc.schema_id
WHERE is_tracked_by_cdc = 1

select name, is_cdc_enabled from sys.databases where is_cdc_enabled = 1

exec sp_helplogreader_agent

select * from master.sys.server_principals where name like 'S%'

exec msdb.dbo.rds_cdc_disable_db 'FICDCCBSS'



exec msdb.dbo.rds_cdc_enable_db 'FICDCCBSS'





exec sys.sp_cdc_add_job @job_type = N'capture',@pollinginterval = 1800, @maxtrans = 1000, @maxscans = 100;
exec sys.sp_cdc_drop_job @job_type = N'capture'

--exec sys.sp_cdc_add_job @job_type = N'cleanup',@retention =4320, @threshold=5000;

select * from sys.sp_cdc

exec sys.sp_cdc_

EXEC sys.sp_cdc_change_job @job_type = 'capture', @pollinginterval = 1800, @maxtrans = 1000, @maxscans = 100


9DF95A15-EA59-4C5E-8C7B-A47BC68DE139	capture	cdc.FICDCCBSS_capture.47271E8B-668F-453C-9D93-75D9A2CC1939	10000	1000	1	1800	0	0


EXEC sys.sp_cdc_start_job @job_type = N'capture';



EXEC sys.sp_cdc_stop_job @job_type = N'capture';
EXEC sys.sp_cdc_stop_job @job_type = N'cleanup';

EXEC sys.sp_cdc_drop_job @job_type = N'capture';
EXEC sys.sp_cdc_drop_job @job_type = N'cleanup';


exec sys.sp_cdc_disable_table @source_schema = N'dbo',  @source_name = N'COPER',  @role_name = N'USER_OPENFINANCE_CDC'



exec sys.sp_cdc_enable_table @source_schema = N'dbo',  @source_name = N'TPROD',  @role_name = N'USER_OPENFINANCE_CDC'


exec sys.sp_cdc_disable_table @source_schema = N'dbo',  @source_name = N'EFINA' , @capture_instance = 'ALL'


 EXEC sys.sp_cdc_help_change_data_capture

EXEC sys.sp_cdc_change_job @job_type = 'capture', @pollinginterval = 1800, @maxtrans = 1000, @maxscans = 100
 


--CPROP
--TPROD

-- FICDCEP - OK
-- FIPROPAUTEP - OK
-- FITABCORPCBSS - OK
--FIPROPAUTCBSS
--FICDCCBSS


EXEC SP_DEPENDS 'dbo.COPER'

 SELECT * --referencing_schema_name, referencing_entity_name,
 --referencing_id, referencing_class_desc, is_caller_dependent
 FROM sys.dm_sql_referencing_entities ('dbo.COPER', 'OBJECT');
 GO






 SELECT        JOB.job_id AS JobID,
     JOB.[name] AS JobName,
	     PRIN.[name] AS Principal 
		 FROM    msdb.dbo.sysjobs AS JOB
		    LEFT JOIN msdb.sys.database_principals AS PRIN ON JOB.owner_sid = PRIN.sid
		order by JOB.name
			



exec rdsadmin.dbo.rds_show_configuration 'cdc_capture_maxtrans';

exec rdsadmin.dbo.rds_set_configuration 'cdc_capture_maxtrans', 1000;