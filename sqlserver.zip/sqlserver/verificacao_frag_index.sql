SELECT 
    OBJECT_NAME(i.object_id) AS TableName,
    i.name AS IndexName,
    i.index_id AS IndexID,
    avg_fragmentation_in_percent AS FragmentationPercent,
    page_count AS PageCount
FROM 
    sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'LIMITED') AS d
JOIN 
    sys.indexes AS i ON d.object_id = i.object_id AND d.index_id = i.index_id
WHERE 
    i.type > 0  -- Exclui índices heap
ORDER BY 
    FragmentationPercent DESC;