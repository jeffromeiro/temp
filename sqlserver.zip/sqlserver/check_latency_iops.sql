WITH IOStats AS
(
    SELECT
        DB_NAME(vfs.database_id) AS DatabaseName,
        SUM(vfs.num_of_reads) AS Reads,
        SUM(vfs.num_of_writes) AS Writes,
        SUM(vfs.num_of_reads + vfs.num_of_writes) AS TotalIOPS,
        CAST(
            SUM(vfs.io_stall_read_ms + vfs.io_stall_write_ms) * 1.0 /
            NULLIF(SUM(vfs.num_of_reads + vfs.num_of_writes),0)
            AS DECIMAL(10,2)
        ) AS AvgLatencyMs
    FROM sys.dm_io_virtual_file_stats(NULL,NULL) vfs
    INNER JOIN sys.master_files mf
        ON vfs.database_id = mf.database_id
        AND vfs.file_id = mf.file_id
    WHERE mf.physical_name LIKE 'P:\%'
    GROUP BY vfs.database_id
)
SELECT
    DatabaseName,
    Reads,
    CAST(Reads * 100.0 / SUM(Reads) OVER() AS DECIMAL(10,2)) AS ReadsPct,

    Writes,
    CAST(Writes * 100.0 / SUM(Writes) OVER() AS DECIMAL(10,2)) AS WritesPct,

    TotalIOPS,
    CAST(TotalIOPS * 100.0 / SUM(TotalIOPS) OVER() AS DECIMAL(10,2)) AS TotalIOPSPct,

    AvgLatencyMs
FROM IOStats
ORDER BY TotalIOPS DESC;
