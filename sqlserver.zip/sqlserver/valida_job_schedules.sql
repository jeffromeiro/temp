USE msdb;
GO

SELECT 
    j.name AS JobName,
    s.name AS ScheduleName,
    js.next_run_date AS NextRunDate,
    -- Formata o hor�rio para HH:MM:SS
    STUFF(STUFF(RIGHT('000000' + CAST(js.next_run_time AS VARCHAR(6)), 6), 3, 0, ':'), 6, 0, ':') AS NextRunTimeFormatted,
    sch.freq_type,
    sch.freq_interval,
    sch.freq_subday_type,
    sch.freq_subday_interval,
    sch.freq_relative_interval,
    sch.freq_recurrence_factor,
    sch.active_start_date,
    STUFF(STUFF(RIGHT('000000' + CAST(sch.active_start_time AS VARCHAR(6)), 6), 3, 0, ':'), 6, 0, ':') AS ActiveStartTimeFormatted,
    sch.active_end_date,
    STUFF(STUFF(RIGHT('000000' + CAST(sch.active_end_time AS VARCHAR(6)), 6), 3, 0, ':'), 6, 0, ':') AS ActiveEndTimeFormatted
FROM 
    sysjobs j
INNER JOIN 
    sysjobschedules js ON j.job_id = js.job_id
INNER JOIN 
    sysschedules sch ON js.schedule_id = sch.schedule_id
LEFT JOIN 
    msdb.dbo.sysschedules s ON js.schedule_id = s.schedule_id
ORDER BY 
    j.name;
