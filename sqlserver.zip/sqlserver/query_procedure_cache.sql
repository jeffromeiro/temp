exec sp_recompile FI_SP_CDC_SelFluxoPrestacoesV38



	SELECT OBJECT_NAME(object_id, database_id) ,execution_count, DB_NAME(database_id) AS BD, last_logical_reads,* 
	FROM SYS.dm_exec_procedure_stats 
	WHERE OBJECT_NAME(object_id, database_id) LIKE '%FI_SP_CDC_SelFluxoPrestacoesV38%'
	--and DB_NAME(database_id)='FIPROPAUTCBSS';
	order by 3 desc;
--FI_sp_INSS_LevantamentoExclusaoV60
--FI_sp_INSS_LevantamentoProrrogacaoDeVencimentoV22

SELECT OBJECT_NAME(object_id, database_id) as object_name ,execution_count, last_elapsed_time/1000000 as last_elapsed_time_seg, DB_NAME(database_id) AS BD, last_logical_reads,* 
FROM SYS.dm_exec_procedure_stats 
--WHERE OBJECT_NAME(object_id, database_id) LIKE '%FI_SP_GD_SelChavesAuxiliaresPorPerfilV3%'
--and DB_NAME(database_id)='FIPROPAUTCBSS';
WHERE execution_count > 10 and
last_elapsed_time > 1000000
order by 3 desc;



dbo.FI_SP_CDCFGTS_LevantamentoExclusoesSaqueV21
dbo.FI_sp_INSS_LevantamentoInclusaoV29
dbo.FI_sp_INSS_LevantamentoProrrogacaoDeVencimentoV22
dbo.FI_sp_INSS_LevantamentoInclusaoV29
dbo.FI_sp_INSS_LevantamentoProrrogacaoDeVencimentoV22

--FI_SP_CDC_SelFluxoPrestacoesV38
--FI_SP_AUT_SelRestricaoNaoMePerturbe_168_V2

exec sp_help 'FI_SP_AUT_SelRestricaoNaoMePerturbe_168_V2'

exec sp_help FI_SP_AUT_ValNaoMePerturbePorTelefone_168_V3


USE FIPROPAUTCBSS

SELECT
    name AS ProcedureName,
    create_date AS DataCriacao,
    modify_date AS DataModificacao
FROM sys.procedures
WHERE name = 'FI_SP_AUT_ValNaoMePerturbePorTelefone_168_V3';



