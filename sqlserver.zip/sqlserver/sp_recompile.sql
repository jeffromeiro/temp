use FICDCCBSS

exec sp_recompile FI_sp_SelOpDadosBasicosV13

