/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [id]
      ,[logDate]
      ,[databaseName]
      ,[logSize]
      ,[logUsed]
  FROM [monitor].[dbo].[logSpaceStats] 
  WHERE databaseName = 'FICDCCBSS'
  --WHERE --databaseName = 'FIMONITORCBSS' and 
   -- logDate='2024-12-14 06:30:00.510'
  order by [logDate] desc
  --order by [logSize] desc



/****** Script for SelectTopNRows command from SSMS  ******/
SELECT dataTime, dbName,
 sum(CurrentSizeMB)/1024 as size_gb, 
 sum(FreeSpaceMB)/1024 as free_gb
  FROM [monitor].[dbo].LogFileSize
  WHERE dbName='FICDCCBSS'
  group by dataTime, dbName
  ORDER BY DataTime DESC