/*select * from monitor.dbo.LatenciaIO  where DatabaseName='FIPROPAUTCBSS'
AND PhysicalName LIKE 'K:%'
 order by DataColeta
 */
 WITH ColetasOrdenadas AS (
    SELECT *,
        ROW_NUMBER() OVER (PARTITION BY PhysicalName ORDER BY DataColeta) AS rn
    FROM monitor.dbo.LatenciaIO
),
Deltas AS (
    SELECT 
        atual.DataColeta AS DataAtual,
        anterior.DataColeta AS DataAnterior,
        atual.PhysicalName,
        atual.DatabaseName,
        atual.NumReads - anterior.NumReads AS DeltaReads,
        atual.NumWrites - anterior.NumWrites AS DeltaWrites,
        atual.ReadLatencyMs * atual.NumReads - anterior.ReadLatencyMs * anterior.NumReads AS DeltaReadStall,
        atual.WriteLatencyMs * atual.NumWrites - anterior.WriteLatencyMs * anterior.NumWrites AS DeltaWriteStall,
        CASE 
            WHEN (atual.NumReads - anterior.NumReads) = 0 THEN 0
            ELSE (atual.ReadLatencyMs * atual.NumReads - anterior.ReadLatencyMs * anterior.NumReads) / (atual.NumReads - anterior.NumReads)
        END AS AvgReadLatencyDelta,
        CASE 
            WHEN (atual.NumWrites - anterior.NumWrites) = 0 THEN 0
            ELSE (atual.WriteLatencyMs * atual.NumWrites - anterior.WriteLatencyMs * anterior.NumWrites) / (atual.NumWrites - anterior.NumWrites)
        END AS AvgWriteLatencyDelta
    FROM ColetasOrdenadas atual
    JOIN ColetasOrdenadas anterior
        ON atual.PhysicalName = anterior.PhysicalName
        AND atual.rn = anterior.rn + 1
)
SELECT * FROM Deltas
WHERE -- DatabaseName='FIPROPAUTCBSS' AND
PhysicalName LIKE 'K:%'
ORDER BY DatabaseName,DataAtual;
