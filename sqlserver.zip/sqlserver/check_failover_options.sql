SELECT 
    ag.name AS [Availability Group],
    ar.replica_server_name AS [Replica Name],
    ar.availability_mode_desc AS [Availability Mode],
    ar.failover_mode_desc AS [Failover Mode],
    ar.primary_role_allow_connections_desc AS [Primary Role Connections],
    ar.secondary_role_allow_connections_desc AS [Secondary Role Connections]
FROM 
    sys.availability_replicas ar
JOIN 
    sys.availability_groups ag ON ar.group_id = ag.group_id;
