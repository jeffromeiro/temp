/* ===== Janela de amostragem ===== */
DECLARE @window_ms int = 10000; -- 10.000 ms = 10s. Pode ajustar.

/* Converte ms -> 'hh:mm:ss.mmm' (varchar) para o WAITFOR DELAY */
DECLARE @h  int = @window_ms / 3600000;
DECLARE @m  int = (@window_ms % 3600000) / 60000;
DECLARE @s  int = (@window_ms % 60000) / 1000;
DECLARE @ms int = @window_ms % 1000;

DECLARE @delay_str varchar(12) =
    RIGHT('00' + CAST(@h  AS varchar(2)), 2) + ':' +
    RIGHT('00' + CAST(@m  AS varchar(2)), 2) + ':' +
    RIGHT('00' + CAST(@s  AS varchar(2)), 2) + '.' +
    RIGHT('000' + CAST(@ms AS varchar(3)), 3);

IF OBJECT_ID('tempdb..#snap1') IS NOT NULL DROP TABLE #snap1;
IF OBJECT_ID('tempdb..#snap2') IS NOT NULL DROP TABLE #snap2;

/* ===== Snapshot 1 ===== */
SELECT 
    r.session_id,
    r.request_id,
    r.cpu_time AS cpu_ms,              -- acumulado desde o in�cio da request
    r.logical_reads,
    r.reads,
    r.writes,
    r.blocking_session_id,
    r.wait_type,
    r.status,
    s.login_name,
    s.host_name,
    s.program_name,
    r.sql_handle,
    r.plan_handle
INTO #snap1
FROM sys.dm_exec_requests AS r
JOIN sys.dm_exec_sessions AS s
  ON s.session_id = r.session_id
WHERE r.session_id <> @@SPID; -- ignora a pr�pria sess�o

/* ===== Espera a janela ===== */
WAITFOR DELAY @delay_str;

/* ===== Snapshot 2 ===== */
SELECT 
    r.session_id,
    r.request_id,
    r.cpu_time AS cpu_ms,
    r.logical_reads,
    r.reads,
    r.writes,
    r.blocking_session_id,
    r.wait_type,
    r.status,
    s.login_name,
    s.host_name,
    s.program_name,
    r.sql_handle,
    r.plan_handle
INTO #snap2
FROM sys.dm_exec_requests AS r
JOIN sys.dm_exec_sessions AS s
  ON s.session_id = r.session_id
WHERE r.session_id <> @@SPID;

/* ===== Deltas e % de CPU dentro do SQL Server ===== */
;WITH deltas AS (
    SELECT 
        s2.session_id,
        s2.request_id,
        dcpu_ms         = s2.cpu_ms - s1.cpu_ms,
        dlogical_reads  = s2.logical_reads - s1.logical_reads,
        dreads          = s2.reads - s1.reads,
        dwrites         = s2.writes - s1.writes,
        s2.blocking_session_id,
        s2.wait_type,
        s2.status,
        s2.login_name,
        s2.host_name,
        s2.program_name,
        s2.sql_handle,
        s2.plan_handle
    FROM #snap2 s2
    JOIN #snap1 s1
      ON s1.session_id = s2.session_id
     AND s1.request_id = s2.request_id
), filtered AS (
    SELECT * FROM deltas WHERE dcpu_ms > 0 -- s� quem consumiu CPU na janela
), totals AS (
    SELECT SUM(dcpu_ms) AS total_cpu_ms FROM filtered
)
SELECT TOP (50)
    f.session_id,
    f.request_id,
    f.dcpu_ms AS cpu_ms_na_janela,
    CAST(100.0 * f.dcpu_ms / NULLIF(t.total_cpu_ms, 0) AS decimal(6,2)) AS pct_cpu_no_SQLServer,
    f.dlogical_reads, f.dreads, f.dwrites,
    f.status, f.wait_type, f.blocking_session_id,
    f.login_name, f.host_name, f.program_name,
    DB_NAME(st.dbid) AS database_name,
    st.text AS query_text
FROM filtered AS f
CROSS APPLY sys.dm_exec_sql_text(f.sql_handle) AS st
CROSS JOIN totals AS t
ORDER BY pct_cpu_no_SQLServer DESC, f.dcpu_ms DESC;
