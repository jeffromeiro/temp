WITH STATS  (ID, Tabela, StatsName, ultAtl, modific, dias, comando)
AS
(
    SELECT DISTINCT
        TB.object_id,
        TB.name AS Tabela,
        ST.name AS StatsName,
        stats.last_updated AS ultAtl,
        stats.modification_counter AS modific,
        DATEDIFF(DAY, stats.last_updated, GETDATE()) AS dias,
        'UPDATE STATISTICS [' + sc.name + '].[' + TB.name + '] [' + ST.name + '] WITH FULLSCAN' AS comando
    FROM sys.tables TB
    INNER JOIN sys.schemas sc ON sc.schema_id = TB.schema_id
    INNER JOIN sys.stats ST ON TB.object_id = ST.object_id
    INNER JOIN sys.indexes IX ON TB.object_id = IX.object_id
    CROSS APPLY sys.dm_db_stats_properties(TB.object_id, ST.stats_id) AS stats
)
SELECT *
FROM STATS --ORDER BY TABELA
 WHERE 
Tabela in ('CLREST')  -- AND
--(modific > 5000 OR dias > 7)
 AND StatsName NOT LIKE '_WA_Sys_%'
ORDER BY dias DESC, modific DESC;




