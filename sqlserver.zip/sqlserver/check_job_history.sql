use monitor

select *--CommandType, count(*)
from CommandLog where
--CommandType='ALTER_INDEX' 
CommandType='UPDATE_STATISTICS'
and 
StartTime > DATEADD(DAY, -2, GETDATE()) 
--StartTime between DATEADD(DAY, -2, GETDATE())  and DATEADD(DAY, -1, GETDATE()) 
--and ObjectName='COPER'
--and DatabaseName='FICDCCBSS'
--group by CommandType
order by StartTime desc ;
--order by ObjectName,IndexName;


use monitor

select DatabaseName, ObjectName, count(*)
from CommandLog where
--CommandType='ALTER_INDEX' 
CommandType='UPDATE_STATISTICS'
and StartTime > DATEADD(DAY, -20, GETDATE())
and datepart(dw,StartTime) not in (1,2)
--and DatabaseName='FICOMISSAOCBSS'
group by ObjectName, DatabaseName

--StartTime between DATEADD(DAY, -2, GETDATE())  and DATEADD(DAY, -1, GETDATE()) 
--and ObjectName='COPER'
--and DatabaseName='FICDCCBSS'
--group by CommandType
--order by ObjectName,IndexName;
