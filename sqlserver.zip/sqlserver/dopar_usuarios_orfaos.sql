DECLARE @SQL NVARCHAR(MAX) = ''

SELECT @SQL = @SQL + '
USE [' + name + '];
SELECT 
    ''USE [' + name + ']; 
	DROP USER ['' + dp.name + ''];'' AS DropCommand
FROM sys.database_principals dp
WHERE dp.type IN (''S'', ''U'') -- SQL or Windows user
  AND dp.sid IS NOT NULL
  AND NOT EXISTS (
      SELECT 1 
      FROM sys.server_principals sp 
      WHERE sp.sid = dp.sid
  )
  AND dp.name NOT IN (''guest'', ''INFORMATION_SCHEMA'', ''sys'');
'
FROM sys.databases
WHERE database_id > 4 -- AND name <> 'FIBACENCBSS';

EXEC sp_executesql @SQL;