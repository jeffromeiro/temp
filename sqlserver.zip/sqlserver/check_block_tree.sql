

SET NOCOUNT ON
GO
 
IF OBJECT_ID('tempdb..#T') IS NOT NULL
BEGIN
    DROP TABLE #T
END
GO
 
 
SELECT 
    SPID, BLOCKED, REPLACE(REPLACE(T.TEXT, CHAR(10), ' '), CHAR(13), ' ') AS BATCH
INTO #T
FROM sys.sysprocesses R 
CROSS APPLY sys.dm_exec_sql_text(R.SQL_HANDLE) T
GO
 
WITH BLOCKERS (SPID, BLOCKED, LEVEL, BATCH)
AS
(
    SELECT 
        SPID, BLOCKED, CAST (REPLICATE ('0', 4-LEN (CAST (SPID AS VARCHAR))) + CAST (SPID AS VARCHAR) AS VARCHAR (1000)) AS LEVEL,
        BATCH 
    FROM #T R
    WHERE 
        (BLOCKED = 0 OR BLOCKED = SPID)
        AND EXISTS (SELECT * FROM #T R2 WHERE R2.BLOCKED = R.SPID AND R2.BLOCKED <> R2.SPID)
    UNION ALL
    SELECT 
        R.SPID, R.BLOCKED,
        CAST(BLOCKERS.LEVEL + RIGHT (CAST ((1000 + R.SPID) AS VARCHAR (100)), 4) AS VARCHAR (1000)) AS LEVEL,
        R.BATCH FROM #T AS R
    INNER JOIN BLOCKERS ON R.BLOCKED = BLOCKERS.SPID 
    WHERE 
        R.BLOCKED > 0 AND R.BLOCKED <> R.SPID
)
SELECT 
    N'    ' + REPLICATE (N'|         ', LEN (LEVEL)/4 - 1) +
    CASE WHEN (LEN(LEVEL)/4 - 1) = 0
    THEN 'HEAD -  '
    ELSE '|------  ' END
    + CAST(SPID AS NVARCHAR (10)) + N' ' + BATCH AS BLOCKING_TREE
FROM BLOCKERS 
ORDER BY LEVEL ASC
GO


WITH BlockingTree AS (
    -- Sess�es bloqueadoras raiz (n�o est�o sendo bloqueadas por ningu�m)
    SELECT 
        r.session_id,
        r.blocking_session_id,
        CAST(r.session_id AS VARCHAR(MAX)) AS BlockChain,
        0 AS Level
    FROM sys.dm_exec_requests r
    WHERE r.blocking_session_id = 0
    UNION ALL
    -- Sess�es bloqueadas por outras
    SELECT 
        r.session_id,
        r.blocking_session_id,
        CAST(bt.BlockChain + ' -> ' + CAST(r.session_id AS VARCHAR(MAX)) AS VARCHAR(MAX)),
        bt.Level + 1
    FROM sys.dm_exec_requests r
    INNER JOIN BlockingTree bt ON r.blocking_session_id = bt.session_id
)
SELECT 
    bt.Level,
    bt.session_id AS SessaoBloqueada,
    bt.blocking_session_id AS SessaoBloqueadora,
    bt.BlockChain,
    s.login_name,
    s.host_name,
    s.program_name,
    r.status,
    r.wait_type,
    r.wait_time,
    DB_NAME(r.database_id) AS database_name,
    st.text AS sql_text
FROM BlockingTree bt
JOIN sys.dm_exec_sessions s ON bt.session_id = s.session_id
JOIN sys.dm_exec_requests r ON bt.session_id = r.session_id
OUTER APPLY sys.dm_exec_sql_text(r.sql_handle) st
where bt.blocking_session_id > 0 
ORDER BY bt.Level, bt.BlockChain;