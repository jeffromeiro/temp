USE MONITOR
GO
SELECT TOP (1000) [Sessao_Bloqueadora]
      ,[Sessao_Bloqueada]
      ,[Login_Sessao_Bloqueadora]
      ,[Program_Sessao_Bloqueadora]
      ,[Hostname_Sessao_Bloqueadora]
      ,[Login_Sessao_Bloqueada]
      ,[Program_Sessao_Bloqueada]
      ,[DatabaseName]
      ,[Tempo_Total_Bloqueio]
      ,[Tempo_Total_Sessao_Bloqueada]
      ,[Tipo_Espera]
      ,[DateTime]
  FROM [monitor].[dbo].[tbl_gera_bloqueios] 
  WHERE DateTime > '2024-12-16 00:00:00.000'
  order by DateTime desc



  select count(*) qtd, Program_Sessao_Bloqueadora, Program_Sessao_Bloqueada, DatabaseName
  FROM [monitor].[dbo].[tbl_gera_bloqueios] 
  where Program_Sessao_Bloqueada is not null
  and DateTime > '2024-12-16 00:00:00.000'
  group by  Program_Sessao_Bloqueadora, Program_Sessao_Bloqueada, DatabaseName
  order by 1 desc


    select count(*) qtd, Program_Sessao_Bloqueadora,  DatabaseName
  FROM [monitor].[dbo].[tbl_gera_bloqueios] 
  where Program_Sessao_Bloqueada is not null
  and DateTime > '2024-12-16 00:00:00.000'
  group by  Program_Sessao_Bloqueadora,  DatabaseName
  order by 1 desc

  select DATEDIFF(SECOND, '00:00:00', CONVERT(TIME, Tempo_Total_Bloqueio)) 
    + DATEPART(MILLISECOND, CONVERT(TIME, Tempo_Total_Bloqueio)) / 1000.0 AS TotalSeconds,*
	FROM [monitor].[dbo].[tbl_gera_bloqueios] 

	select Program_Sessao_Bloqueadora,avg(DATEDIFF(SECOND, '00:00:00', CONVERT(TIME, Tempo_Total_Bloqueio)) 
    + DATEPART(MILLISECOND, CONVERT(TIME, Tempo_Total_Bloqueio)) / 1000.0) as avg_seconds, count(*)
	FROM [monitor].[dbo].[tbl_gera_bloqueios] 
	group by Program_Sessao_Bloqueadora
	order by 3 desc

	

   TimeString,
    -- Converte a string para o tipo TIME
    CAST(TimeString AS TIME) AS TimeValue,
    -- Calcula o total de minutos
    DATEPART(HOUR, CAST(TimeString AS TIME)) * 60 + 
    DATEPART(MINUTE, CAST(TimeString AS TIME)) + 
    DATEPART(SECOND, CAST(TimeString AS TIME)) / 60.0 + 
    DATEPART(MILLISECOND, CAST(TimeString AS TIME)) / 60000.0 AS TotalMinutes