SELECT TOP 20
    total_worker_time/1000 AS cpu_ms,
    execution_count,
    total_worker_time / execution_count AS avg_cpu,
    SUBSTRING(qt.text, 1, 2000) AS query_text
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) qt
ORDER BY total_worker_time DESC;
