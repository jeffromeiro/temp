SELECT 
    CAST(event_data AS XML).value('(/event/@timestamp)[1]', 'DATETIME') AS [Data_Hora_UTC],
    CAST(event_data AS XML).query('/event/data[@name="xml_report"]/value/deadlock') AS [XML_Deadlock]
FROM sys.fn_xe_file_target_read_file('system_health*.xel', NULL, NULL, NULL)
WHERE object_name = 'xml_deadlock_report'
ORDER BY [Data_Hora_UTC] DESC;

-- salvar o arquivo xml com a extensão .xdl para visualizar graficamente o deadlock