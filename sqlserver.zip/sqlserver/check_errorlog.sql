DECLARE @Inicio DATETIME = DATEADD(day, -3, GETDATE());
DECLARE @Fim DATETIME = GETDATE();

--DECLARE @Inicio DATETIME = '2026-04-15 21:00:00.830';
--DECLARE @Fim DATETIME = '2026-04-15 23:59:59.830';


-- Par�metros: 
-- 0 (Log atual), 1 (SQL Server Engine), 
-- BuscaTexto1 (null), BuscaTexto2 (null), 
-- DataInicio, DataFim
EXEC sys.xp_readerrorlog 0, 1, NULL, NULL, @Inicio, @Fim;
