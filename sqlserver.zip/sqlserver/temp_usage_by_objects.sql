SELECT 
    t.NAME AS TableName,
    SUM(a.total_pages) * 8 AS TotalKB,
    SUM(a.total_pages) * 8 / 1024 AS TotalMB
FROM tempdb.sys.tables t
JOIN tempdb.sys.indexes i ON t.object_id = i.object_id
JOIN tempdb.sys.partitions p ON i.object_id = p.object_id AND i.index_id = p.index_id
JOIN tempdb.sys.allocation_units a ON p.partition_id = a.container_id
WHERE t.name LIKE '%#ARQUIVO_XML%'
GROUP BY t.NAME
order by 3 desc;

-- #ECONTA_PREVIA______________________________________________________________________________________________________0000153C87DF	8835712	8628