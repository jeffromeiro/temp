/* ===== Janela de amostragem ===== */
IF OBJECT_ID('tempdb..#snap1_cpu') IS NOT NULL DROP TABLE #snap1_cpu;
IF OBJECT_ID('tempdb..#snap2_cpu') IS NOT NULL DROP TABLE #snap2_cpu;
GO

DECLARE @window_ms int = 10000; 
DECLARE @delay_str varchar(12) = '00:00:10.000'; 

/* ===== Snapshot 1 ===== */
SELECT 
    CAST(ISNULL(s.program_name, '(Nome de Programa n�o Definido)') AS VARCHAR(255)) AS p_name,
    SUM(CAST(r.cpu_time AS bigint)) AS cpu_sum,
    SUM(CAST(r.logical_reads AS bigint) + CAST(r.reads AS bigint)) AS io_sum,
    COUNT(*) AS req_count
INTO #snap1_cpu
FROM sys.dm_exec_requests AS r
JOIN sys.dm_exec_sessions AS s ON s.session_id = r.session_id
WHERE r.session_id <> @@SPID
GROUP BY ISNULL(s.program_name, '(Nome de Programa n�o Definido)');

/* ===== Espera a janela ===== */
WAITFOR DELAY @delay_str;

/* ===== Snapshot 2 ===== */
SELECT 
    CAST(ISNULL(s.program_name, '(Nome de Programa n�o Definido)') AS VARCHAR(255)) AS p_name,
    SUM(CAST(r.cpu_time AS bigint)) AS cpu_sum,
    SUM(CAST(r.logical_reads AS bigint) + CAST(r.reads AS bigint)) AS io_sum,
    COUNT(*) AS req_count
INTO #snap2_cpu
FROM sys.dm_exec_requests AS r
JOIN sys.dm_exec_sessions AS s ON s.session_id = r.session_id
WHERE r.session_id <> @@SPID
GROUP BY ISNULL(s.program_name, '(Nome de Programa n�o Definido)');
GO

/* ===== Processamento Final focado em CPU ===== */
DECLARE @total_cpu_global bigint;

SELECT 
    s2.p_name AS program_name,
    -- Usamos ABS para capturar a varia��o mesmo se a sess�o resetou
    ABS(s2.cpu_sum - ISNULL(s1.cpu_sum, 0)) AS cpu_ms_variacao,
    ABS(s2.io_sum - ISNULL(s1.io_sum, 0)) AS io_reads_variacao,
    s2.req_count AS qtd_requests_final
INTO #final_cpu_result
FROM #snap2_cpu s2
LEFT JOIN #snap1_cpu s1 ON s1.p_name = s2.p_name;

SELECT @total_cpu_global = SUM(cpu_ms_variacao) FROM #final_cpu_result WHERE cpu_ms_variacao > 0;

SELECT 
    program_name,
    cpu_ms_variacao AS cpu_consumida_ms,
    CAST(100.0 * cpu_ms_variacao / NULLIF(@total_cpu_global, 0) AS decimal(18,2)) AS pct_cpu_total,
    io_reads_variacao AS io_total_no_periodo,
    qtd_requests_final
FROM #final_cpu_result
-- Removido o filtro WHERE >= 0 para garantir que tudo que variou apare�a
ORDER BY cpu_ms_variacao DESC;

-- Limpeza
DROP TABLE #snap1_cpu;
DROP TABLE #snap2_cpu;
DROP TABLE #final_cpu_result;
