SELECT 
    r.session_id,
    CASE 
        -- Caso o comando contenha '\BACKUP\' e '\FULL\', extrai o nome entre eles
        WHEN CHARINDEX('\BACKUP\', t.text) > 0 AND CHARINDEX('\FULL\', t.text) > 0 THEN
            SUBSTRING(
                t.text,
                CHARINDEX('\BACKUP\', t.text) + 8,
                CHARINDEX('\FULL\', t.text) - CHARINDEX('\BACKUP\', t.text) - 8
            )
        -- Caso o comando seja 'BACKUP DATABASE [NOME]', extrai o nome entre os colchetes
        WHEN t.text LIKE 'BACKUP DATABASE [%]%' THEN
            SUBSTRING(
                t.text,
                CHARINDEX('[', t.text) + 1,
                CHARINDEX(']', t.text) - CHARINDEX('[', t.text) - 1
            )
        ELSE NULL
    END AS database_name_extracted,
    r.command,
    r.status,
    r.percent_complete,
    r.start_time,
    STR(r.estimated_completion_time / 1000.0, 10, 2) AS estimated_completion_seconds,
    STR(r.estimated_completion_time / 1000.0 / 3600.0, 10, 2) AS estimated_completion_hours,
    STR(r.total_elapsed_time / 1000.0, 10, 2) AS total_elapsed_seconds,
    STR(r.total_elapsed_time / 1000.0 / 3600.0, 10, 2) AS total_elapsed_hours,
    s.login_name,
    s.host_name,
    s.program_name
FROM 
    sys.dm_exec_requests r
JOIN 
    sys.dm_exec_sessions s ON r.session_id = s.session_id
CROSS APPLY 
    sys.dm_exec_sql_text(r.sql_handle) AS t
WHERE 
    r.command LIKE 'RESTORE%' OR r.command LIKE 'BACKUP%';
