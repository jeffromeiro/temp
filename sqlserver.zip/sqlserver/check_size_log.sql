dbcc sqlperf(logspace)

