#!/bin/bash

#sqlcmd -C -S prd-sqlserver-funcao.ceip7fi02lcw.sa-east-1.rds.amazonaws.com -U dba_monitor -P dba_monitor -d master -i check_all_table_size.sql -W -w 999 -s";" >> check_all_table_size.csv
sqlcmd -C -S prd-sqlserver-funcao.ceip7fi02lcw.sa-east-1.rds.amazonaws.com -U dba_monitor -P dba_monitor -d master -i check_all_index_size.sql -W -w 999 -s";" >> check_all_index_size.csv
